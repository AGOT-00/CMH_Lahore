﻿using System.Diagnostics.CodeAnalysis;
[assembly: SuppressMessage("Interoperability", "CA1416:Validate platform compatibility", Justification = "<Pending>", Scope = "member", Target = "~M:CMH_Lahore.Models.Unit.Getportfromos~CMH_Lahore.Models.GSMComPort")]
