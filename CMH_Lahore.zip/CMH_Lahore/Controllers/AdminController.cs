﻿using CMH_Lahore.DB;
using CMH_Lahore.Models;
using Microsoft.AspNetCore.Mvc;
//Login Issue
//Feedback Upload Status

namespace CMH_Lahore.Controllers
{
    public class AdminController : Controller
    {
        private readonly Database _DB;
        Admin? SignedIn;

        public IActionResult Index()
        {
            if (SignedIn == null)
            {
                return RedirectToAction("Login");
            }
            return View(SignedIn);
        }

        public AdminController(Database DB)
        {
            if (SignedIn != null)
            {
                Console.WriteLine('H');
            }
            _DB = DB;
        }

        [HttpGet]
        public IActionResult Login()
        {
            AdminDT obj = new();
            return View(obj);
        }

        [HttpPost]
        public async Task<IActionResult> Login(AdminDT admin)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var objs1 = _DB.Admins.ToList();
                    var objs = _DB.Admins.FirstOrDefault(u => u.ID == admin.ID && u.Password == admin.Password);

                    if (objs != null)
                    {
                        SignedIn = AdminFactory.GetAdmin(objs);
                        return RedirectToAction("Complaints", "Admin");
                    }
                    else
                    {
                        ModelState.AddModelError("Login-Error", "Wrong Credientials");
                    }
                }
                catch (Exception e)
                {
                    SignedIn = null;
                    ModelState.AddModelError("Login-Error", "Error Detected");
                }

            }
            return View(admin);
        }

        public IActionResult Logout()
        {
            SignedIn = null;
            return RedirectToAction("Login", "Admin");
        }

        public IActionResult Department()
        {
            IEnumerable<Department> DepartmentList = _DB.Departments.ToList();
            return View(DepartmentList);
        }

        public IActionResult DeleteDepartment(int? id)
        {
            if (id > 4)
            {
                var DepartmentObject = _DB.Departments.Find(id);
                if (DepartmentObject != null)
                {
                    _DB.Departments.Remove(DepartmentObject);
                    _DB.SaveChanges();
                }
            }

            return RedirectToAction("Department", "Admin");
        }

        public IActionResult AddDepartment()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Changepswd()
        {
            if (SignedIn != null)
            {
                passwordchanger Obj = new();
                return View(Obj);
            }
            return RedirectToAction("Login", "Admin");
        }

        [HttpPost]
        public IActionResult Changepswd(passwordchanger Obj)
        {
            if (SignedIn != null)
            {
                Admin? AdminAccount = _DB.Admins.Find(SignedIn.ID);
                if (AdminAccount != null && AdminAccount.verifypassword(Obj.OldPassword))
                {
                    if (Obj.NewPassword == Obj.ConfirmPassword)
                    {
                        AdminAccount.Password = Obj.NewPassword;
                        _DB.SaveChanges();
                        ModelState.AddModelError("Password-Changed", "Your Password Has Been Changed");

                    }
                    else
                    {
                        ModelState.AddModelError("Password-Error", "New Password and Confirm Password do not match");
                    }
                    return RedirectToAction("Logout", "Admin");
                }
                else
                {
                    ModelState.AddModelError("Password-Error", "Old Password is incorrect");
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Complaints(IEnumerable<Complaint> ComplaintList, string filter = "")
        {
            if (SignedIn != null)
            {
                //IEnumerable<Complaint> 
                ComplaintList = SignedIn.GetListofComplaint(_DB);

                //_DB.Complaints.ToList();

                //switch (filter)
                //{
                //    case "DateASC":
                //        ComplaintList = ComplaintList.OrderBy(c => c.DOI);
                //        break;
                //    case "Status":
                //        ComplaintList = ComplaintList.OrderBy(c => c.status);
                //        break;
                //}

                return View(ComplaintList);
                return View();
            }
            return RedirectToAction("Login", "Admin");
        }

        [HttpPost]
        public IActionResult Complaints(int id, IEnumerable<Complaint> Listing, string filter = "")
        {
            if (SignedIn != null)
            {

                IEnumerable<Complaint> ComplaintList = SignedIn.GetListofComplaint(_DB);//_DB.Complaints.ToList();

                switch (filter)
                {
                    case "DateASC":
                        ComplaintList = ComplaintList.OrderBy(c => c.DOI);
                        break;
                    case "Status":
                        ComplaintList = ComplaintList.OrderBy(c => c.status);
                        break;
                }

                return View(ComplaintList);
                return View();
            }
            return RedirectToAction("Login", "Admin");
        }

        [HttpGet]
        public IActionResult ComplaintDetail(int? ID)
        {
            if (SignedIn != null)
            {
                var DbObj = _DB.Complaints.Find(ID);
                if (DbObj != null)
                {
                    IEnumerable<Department> ComplaintList = _DB.Departments.ToList();
                    complaintdetaildt Obj = new(DbObj, ComplaintList, SignedIn.getadmintype(), _DB.Explainations.Find(ID), _DB.comments.Find(ID));

                    return View(Obj);
                }
            }
            return NotFound();
        }

        protected int statuscheck(int status)
        {
            switch (SignedIn.getadmintype())
            {
                case "ComplaintOfficer":
                    if (status == 2 || status == 4)
                    {
                        status = 0;
                    }
                    return status;
                    break;
                case "AssistantCommandent":
                    return status;
                    break;
            }
            return 0;
        }

        [HttpPost]
        public IActionResult ComplaintDetail(int id, int DepartmentSelection, string Explain, string ComplaintType, int CurrentComplaintStatus)
        {
            if (SignedIn != null)
            {
                var DbObj = _DB.Complaints.Find(id);

                if (DbObj != null)
                {
                    DbObj.ComplaintType = ComplaintType;
                    DbObj.Department = DepartmentSelection;

                    DbObj.status = statuscheck(CurrentComplaintStatus);

                    explaination entry = _DB.Explainations.Find(id);

                    if (entry == null)
                    {
                        entry = new();
                        _DB.Explainations.Add(entry);
                    }

                    entry.id = id;
                    entry.explain = Explain;

                    _DB.SaveChanges();
                    return RedirectToAction("Complaints", "Admin");
                }
            }
            return NotFound();
        }

        public IActionResult savecommandentcomment(int id, string Comment)
        {
            if (SignedIn != null)
            {
                var DbObj = _DB.Complaints.Find(id);

                if (DbObj != null)
                {

                    comment entry = _DB.comments.Find(id);

                    if (entry == null)
                    {
                        entry = new();
                        _DB.comments.Add(entry);
                    }

                    entry.id = id;
                    entry.commenterid = SignedIn.ID;
                    entry.comments = Comment;

                    _DB.SaveChanges();
                }
            }
            return Redirect(Request.GetTypedHeaders().Referer.ToString());
        }

        public IActionResult sendbacktoCO(int? id)
        {
            if (SignedIn != null && SignedIn.getadmintype() == "AssistantCommandent" && id!=null)
            {
                var DbObj = _DB.Complaints.Find(id);

                if (DbObj != null)
                {
                    DbObj.status = 0;
                    DbObj.ComplaintType = "None";
                    _DB.SaveChanges();
                }
            }
            return RedirectToAction("Complaints", "Admin");
        }

        public IActionResult whoamiloggedin()
        {
            return View(SignedIn);
        }

        public IActionResult complaintstatus(int? id)
        {
            if (SignedIn != null && id != null)
            {
                var DbObj = _DB.Complaints.Find(id);
                if (DbObj != null)
                {
                    if (DbObj.status == 1)
                    {
                        DbObj.status = 0;
                        _DB.SaveChanges();
                    }
                    else
                    {
                        DbObj.status = 1;
                        _DB.SaveChanges();
                    }
                    return RedirectToAction("Complaints", "Admin");
                }
            }
            return NotFound();
        }
    }
}
